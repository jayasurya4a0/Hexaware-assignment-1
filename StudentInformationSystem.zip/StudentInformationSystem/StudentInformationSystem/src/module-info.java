/**
 * 
 */
/**
 * 
 */
module StudentInformationSystem {
	
		requires java.sql; 
}